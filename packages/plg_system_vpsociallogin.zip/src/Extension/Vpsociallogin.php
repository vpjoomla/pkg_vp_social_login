<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Extension;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Event\Event;
use Joomla\Event\SubscriberInterface;
use Vpjoomla\Plugin\System\Vpsociallogin\Helper\Authenticator;
use Vpjoomla\Plugin\System\Vpsociallogin\Helper\ProviderRegistry;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\TelegramProvider;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') || die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * VP Social Login system plugin.
 *
 * Renders social login buttons inside any Joomla login form (via the native
 * onUserLoginButtons event) and handles the OAuth2 / Telegram round-trip through
 * the com_ajax endpoint (onAjaxVpsociallogin).
 */
final class Vpsociallogin extends CMSPlugin implements SubscriberInterface
{
    /**
     * Load plugin language files automatically.
     *
     * @var boolean
     */
    protected $autoloadLanguage = true;

    /**
     * Cached provider registry.
     *
     * @var ProviderRegistry|null
     */
    private ?ProviderRegistry $registry = null;

    /**
     * Returns the events this plugin subscribes to.
     *
     * @return array
     */
    public static function getSubscribedEvents(): array
    {
        return [
            'onUserLoginButtons'   => 'onUserLoginButtons',
            'onAjaxVpsociallogin'  => 'onAjaxVpsociallogin',
        ];
    }

    /**
     * Inject social login buttons into a login form.
     *
     * @param   Event  $event  Arguments: [0] => (string) HTML id of the form.
     *
     * @return  void
     */
    public function onUserLoginButtons(Event $event): void
    {
        if (!$this->canDisplayButtons()) {
            return;
        }

        $app      = $this->getApplication();
        $registry = $this->getRegistry();
        $buttons  = [];

        // Only redirect-based (OAuth2) providers can live inside the login form.
        // Telegram requires its own widget and is rendered by mod_vp_social_login.
        foreach ($registry->getEnabledProviders() as $provider) {
            if (!$provider->isRedirectFlow()) {
                continue;
            }

            $buttons[] = [
                'label'            => $provider->getLabel(),
                'tooltip'          => Text::sprintf('PLG_SYSTEM_VPSOCIALLOGIN_BTN_TOOLTIP', $provider->getTitle()),
                'id'               => 'vpsl-btn-' . $provider->getKey() . '-' . bin2hex(random_bytes(4)),
                'class'            => 'vp-social-login-button vpsl-' . $provider->getKey(),
                'data-vpsl-url'    => $this->buildStartUrl($provider->getKey()),
                'svg'              => $provider->getIcon(),
            ];
        }

        // Telegram is not a redirect (OAuth2) provider, so it is added explicitly.
        // It links straight to Telegram's OAuth endpoint; on return, buttons.js
        // reads the #tgAuthResult fragment (via data-vpsl-callback) and forwards it.
        $telegram = $registry->getProvider('telegram');

        if ($telegram instanceof TelegramProvider) {
            $buttons[] = [
                'label'              => $telegram->getLabel(),
                'tooltip'            => Text::sprintf('PLG_SYSTEM_VPSOCIALLOGIN_BTN_TOOLTIP', $telegram->getTitle()),
                'id'                 => 'vpsl-btn-telegram-' . bin2hex(random_bytes(4)),
                'class'              => 'vp-social-login-button vpsl-telegram',
                'data-vpsl-url'      => $telegram->buildAuthUrl(Uri::current()),
                'data-vpsl-callback' => $this->buildCallbackUrl('telegram'),
                'svg'                => $telegram->getIcon(),
            ];
        }

        if (empty($buttons)) {
            return;
        }

        // Remember where the user was, so we can return there after login.
        $app->getSession()->set('vpsociallogin.return_url', Uri::current());

        $this->loadAssets();

        $result   = $event->getArgument('result') ?: [];
        $result   = \is_array($result) ? $result : [$result];
        $result[] = $buttons;
        $event->setArgument('result', $result);
    }

    /**
     * com_ajax entry point. Handles both starting the flow and the provider callback.
     *
     * URL: index.php?option=com_ajax&group=system&plugin=vpsociallogin&format=raw&vpsl=...
     *
     * @param   Event  $event
     *
     * @return  void
     */
    public function onAjaxVpsociallogin(Event $event): void
    {
        $app    = $this->getApplication();
        $input  = $app->getInput();
        $action = $input->getCmd('vpsl', '');

        $authenticator = new Authenticator($app, $this->params, $this->getRegistry());

        switch ($action) {
            case 'auth':
                $authenticator->start($input->getCmd('provider', ''));
                break;

            case 'callback':
                $authenticator->callback($input->getCmd('provider', ''));
                break;

            case 'link':
                if (!Session::checkToken('get')) {
                    $app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
                    $app->redirect(Uri::root());
                    break;
                }

                $authenticator->startLink($input->getCmd('provider', ''));
                break;

            case 'unlink':
                if (!Session::checkToken('get')) {
                    $app->enqueueMessage(Text::_('JINVALID_TOKEN'), 'error');
                    $app->redirect(Uri::root());
                    break;
                }

                $authenticator->unlink($input->getCmd('provider', ''));
                break;

            default:
                // Nothing to do.
                break;
        }
    }

    /**
     * Build the URL that starts the auth flow for a given provider.
     *
     * @param   string  $providerKey
     *
     * @return  string
     */
    private function buildStartUrl(string $providerKey): string
    {
        return Uri::root()
            . 'index.php?option=com_ajax&group=system&plugin=vpsociallogin&format=raw'
            . '&vpsl=auth&provider=' . urlencode($providerKey);
    }

    /**
     * Build the com_ajax callback URL for a given provider.
     *
     * @param   string  $providerKey
     *
     * @return  string
     */
    private function buildCallbackUrl(string $providerKey): string
    {
        return Uri::root()
            . 'index.php?option=com_ajax&group=system&plugin=vpsociallogin&format=raw'
            . '&vpsl=callback&provider=' . urlencode($providerKey);
    }

    /**
     * Get (and cache) the provider registry.
     *
     * @return ProviderRegistry
     */
    private function getRegistry(): ProviderRegistry
    {
        if ($this->registry === null) {
            $this->registry = new ProviderRegistry($this->params, $this->getApplication());
        }

        return $this->registry;
    }

    /**
     * Whether buttons should be displayed in the current context.
     *
     * @return boolean
     */
    private function canDisplayButtons(): bool
    {
        $app = $this->getApplication();

        if (!($app instanceof CMSApplicationInterface)) {
            return false;
        }

        // Only the public site frontend (login forms in admin are out of scope for social login).
        if (!$app->isClient('site')) {
            return false;
        }

        $identity = $app->getIdentity();

        if ($identity === null || !$identity->guest) {
            return false;
        }

        try {
            $document = $app->getDocument();
        } catch (\Throwable) {
            return false;
        }

        return $document instanceof HtmlDocument;
    }

    /**
     * Register and attach the button CSS/JS.
     *
     * @return void
     */
    private function loadAssets(): void
    {
        $wa = $this->getApplication()->getDocument()->getWebAssetManager();

        $wa->registerAndUseStyle(
            'plg_system_vpsociallogin.buttons',
            'plg_system_vpsociallogin/vpsociallogin.css'
        );

        $wa->registerAndUseScript(
            'plg_system_vpsociallogin.buttons',
            'plg_system_vpsociallogin/buttons.js',
            [],
            ['defer' => true]
        );
    }
}
