<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Provider;

use Vpjoomla\Plugin\System\Vpsociallogin\Helper\Profile;

\defined('_JEXEC') || die;

/**
 * Sign in with Discord.
 */
final class DiscordProvider extends AbstractOAuth2Provider
{
    public function getKey(): string
    {
        return 'discord';
    }

    public function getTitle(): string
    {
        return 'Discord';
    }

    public function getLabel(): string
    {
        return 'PLG_SYSTEM_VPSOCIALLOGIN_LOGIN_DISCORD';
    }

    protected function getAuthEndpoint(): string
    {
        return 'https://discord.com/oauth2/authorize';
    }

    protected function getTokenEndpoint(): string
    {
        return 'https://discord.com/api/oauth2/token';
    }

    protected function getScope(): string
    {
        return 'identify email';
    }

    protected function mapProfile(string $accessToken): Profile
    {
        $data = $this->getJson('https://discord.com/api/users/@me', $accessToken);

        if (empty($data['id'])) {
            throw new \RuntimeException('Discord did not return a user id.');
        }

        $avatar = null;

        if (!empty($data['avatar'])) {
            $avatar = 'https://cdn.discordapp.com/avatars/' . $data['id'] . '/' . $data['avatar'] . '.png';
        }

        return new Profile(
            provider: $this->getKey(),
            providerUserId: (string) $data['id'],
            email: isset($data['email']) ? (string) $data['email'] : null,
            // Discord exposes a "verified" flag describing the e-mail.
            emailVerified: !empty($data['verified']),
            name: isset($data['global_name']) && $data['global_name'] !== null
                ? (string) $data['global_name']
                : (isset($data['username']) ? (string) $data['username'] : null),
            username: isset($data['username']) ? (string) $data['username'] : null,
            avatar: $avatar
        );
    }

    public function getIcon(): string
    {
        return <<<'SVG'
<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M20.3 4.4A19.8 19.8 0 0 0 15.4 3l-.3.5c1.7.4 3.2 1 4.6 1.9a16.5 16.5 0 0 0-14.5 0c1.5-.9 3-1.5 4.6-1.9L9.6 3a19.8 19.8 0 0 0-5 1.4C1.6 8.8.8 13.1 1.2 17.3a20 20 0 0 0 6 3l.8-1.3c-.7-.2-1.3-.5-1.9-.9l.5-.3a14.2 14.2 0 0 0 12.1 0l.5.3c-.6.4-1.2.7-1.9.9l.8 1.3a20 20 0 0 0 6-3c.5-4.8-.8-9.1-3.8-12.9zM8.7 14.8c-1 0-1.7-.9-1.7-2s.8-2 1.7-2 1.7.9 1.7 2-.7 2-1.7 2zm6.6 0c-1 0-1.7-.9-1.7-2s.8-2 1.7-2 1.7.9 1.7 2-.7 2-1.7 2z"/></svg>
SVG;
    }
}
