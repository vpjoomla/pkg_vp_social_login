<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Provider;

use Vpjoomla\Plugin\System\Vpsociallogin\Helper\Profile;

\defined('_JEXEC') || die;

/**
 * Sign in with Google (OpenID Connect).
 */
final class GoogleProvider extends AbstractOAuth2Provider
{
    public function getKey(): string
    {
        return 'google';
    }

    public function getTitle(): string
    {
        return 'Google';
    }

    public function getLabel(): string
    {
        return 'PLG_SYSTEM_VPSOCIALLOGIN_LOGIN_GOOGLE';
    }

    protected function getAuthEndpoint(): string
    {
        return 'https://accounts.google.com/o/oauth2/v2/auth';
    }

    protected function getTokenEndpoint(): string
    {
        return 'https://oauth2.googleapis.com/token';
    }

    protected function getScope(): string
    {
        return 'openid email profile';
    }

    protected function extraAuthParams(): array
    {
        return [
            'access_type' => 'online',
            'prompt'      => 'select_account',
        ];
    }

    protected function mapProfile(string $accessToken): Profile
    {
        $data = $this->getJson('https://openidconnect.googleapis.com/v1/userinfo', $accessToken);

        if (empty($data['sub'])) {
            throw new \RuntimeException('Google did not return a user id.');
        }

        return new Profile(
            provider: $this->getKey(),
            providerUserId: (string) $data['sub'],
            email: isset($data['email']) ? (string) $data['email'] : null,
            emailVerified: !empty($data['email_verified']),
            name: isset($data['name']) ? (string) $data['name'] : null,
            username: isset($data['email']) ? strstr((string) $data['email'], '@', true) : null,
            avatar: isset($data['picture']) ? (string) $data['picture'] : null
        );
    }

    public function getIcon(): string
    {
        return <<<'SVG'
<svg viewBox="0 0 48 48" width="20" height="20" aria-hidden="true" focusable="false"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6.1 8-11.3 8a12 12 0 1 1 0-24c3 0 5.8 1.1 7.9 3l5.7-5.7A20 20 0 1 0 24 44a20 20 0 0 0 19.6-23.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8A12 12 0 0 1 24 12c3 0 5.8 1.1 7.9 3l5.7-5.7A20 20 0 0 0 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2A12 12 0 0 1 12.7 28l-6.6 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3a12 12 0 0 1-4.1 5.6l6.2 5.2C37 38.9 44 34 44 24c0-1.2-.1-2.4-.4-3.5z"/></svg>
SVG;
    }
}
