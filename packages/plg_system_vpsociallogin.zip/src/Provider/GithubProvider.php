<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Provider;

use Vpjoomla\Plugin\System\Vpsociallogin\Helper\Profile;

\defined('_JEXEC') || die;

/**
 * Sign in with GitHub.
 */
final class GithubProvider extends AbstractOAuth2Provider
{
    /**
     * GitHub requires a User-Agent on every API request.
     */
    private const UA = ['User-Agent' => 'VPJoomla-SocialLogin'];

    public function getKey(): string
    {
        return 'github';
    }

    public function getTitle(): string
    {
        return 'GitHub';
    }

    public function getLabel(): string
    {
        return 'PLG_SYSTEM_VPSOCIALLOGIN_LOGIN_GITHUB';
    }

    protected function getAuthEndpoint(): string
    {
        return 'https://github.com/login/oauth/authorize';
    }

    protected function getTokenEndpoint(): string
    {
        return 'https://github.com/login/oauth/access_token';
    }

    protected function getScope(): string
    {
        return 'read:user user:email';
    }

    protected function mapProfile(string $accessToken): Profile
    {
        $data = $this->getJson('https://api.github.com/user', $accessToken, self::UA);

        if (empty($data['id'])) {
            throw new \RuntimeException('GitHub did not return a user id.');
        }

        $email         = isset($data['email']) ? (string) $data['email'] : null;
        $emailVerified = false;

        // Primary e-mail can be private and absent from /user; fetch it explicitly.
        if ($email === null || $email === '') {
            [$email, $emailVerified] = $this->resolvePrimaryEmail($accessToken);
        } else {
            // /user does not expose a verified flag, so treat as verified only via /user/emails.
            [$resolved, $verified] = $this->resolvePrimaryEmail($accessToken);

            if ($resolved !== null && strcasecmp($resolved, $email) === 0) {
                $emailVerified = $verified;
            }
        }

        return new Profile(
            provider: $this->getKey(),
            providerUserId: (string) $data['id'],
            email: $email,
            emailVerified: $emailVerified,
            name: !empty($data['name']) ? (string) $data['name'] : (string) ($data['login'] ?? ''),
            username: isset($data['login']) ? (string) $data['login'] : null,
            avatar: isset($data['avatar_url']) ? (string) $data['avatar_url'] : null
        );
    }

    /**
     * Resolve the primary verified e-mail from /user/emails.
     *
     * @param   string  $accessToken
     *
     * @return  array{0: ?string, 1: bool}
     */
    private function resolvePrimaryEmail(string $accessToken): array
    {
        try {
            $emails = $this->getJson('https://api.github.com/user/emails', $accessToken, self::UA);
        } catch (\Throwable) {
            return [null, false];
        }

        foreach ($emails as $entry) {
            if (!empty($entry['primary'])) {
                return [(string) $entry['email'], !empty($entry['verified'])];
            }
        }

        // Fall back to the first verified address.
        foreach ($emails as $entry) {
            if (!empty($entry['verified'])) {
                return [(string) $entry['email'], true];
            }
        }

        return [null, false];
    }

    public function getIcon(): string
    {
        return <<<'SVG'
<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M12 .5A11.5 11.5 0 0 0 .5 12a11.5 11.5 0 0 0 7.9 10.9c.6.1.8-.2.8-.5v-2c-3.2.7-3.9-1.4-3.9-1.4-.5-1.3-1.3-1.7-1.3-1.7-1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1 1.8 2.8 1.3 3.4 1 .1-.8.4-1.3.7-1.6-2.6-.3-5.3-1.3-5.3-5.7 0-1.3.5-2.3 1.2-3.2-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0C17 5 18 5.3 18 5.3c.6 1.6.2 2.8.1 3.1.8.9 1.2 1.9 1.2 3.2 0 4.4-2.7 5.4-5.3 5.7.4.4.8 1.1.8 2.2v3.3c0 .3.2.6.8.5A11.5 11.5 0 0 0 23.5 12 11.5 11.5 0 0 0 12 .5z"/></svg>
SVG;
    }
}
