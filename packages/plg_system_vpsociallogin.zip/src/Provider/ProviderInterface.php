<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Provider;

use Vpjoomla\Plugin\System\Vpsociallogin\Helper\Profile;

\defined('_JEXEC') || die;

/**
 * Contract implemented by every social login provider.
 */
interface ProviderInterface
{
    /**
     * Machine key, e.g. "google".
     *
     * @return string
     */
    public function getKey(): string;

    /**
     * Human title, e.g. "Google".
     *
     * @return string
     */
    public function getTitle(): string;

    /**
     * Language key used for the button label.
     *
     * @return string
     */
    public function getLabel(): string;

    /**
     * Inline SVG markup for the provider icon.
     *
     * @return string
     */
    public function getIcon(): string;

    /**
     * Whether this provider uses a redirect (OAuth2) flow.
     * Returns false for widget-based providers such as Telegram.
     *
     * @return boolean
     */
    public function isRedirectFlow(): bool;

    /**
     * Build the provider authorization URL the user is redirected to.
     *
     * @param   string  $state        Anti-CSRF state token.
     * @param   string  $redirectUri  Absolute callback URL registered with the provider.
     *
     * @return  string
     */
    public function getAuthorizationUrl(string $state, string $redirectUri): string;

    /**
     * Resolve the authenticated user's normalized profile from the callback request.
     *
     * @param   array   $request      The full request data ($input->getArray()).
     * @param   string  $redirectUri  Absolute callback URL (must match the auth request).
     *
     * @return  Profile
     *
     * @throws  \RuntimeException on any authentication failure.
     */
    public function fetchProfile(array $request, string $redirectUri): Profile;
}
