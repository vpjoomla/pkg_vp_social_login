<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Provider;

use Joomla\CMS\Http\HttpFactory;
use Vpjoomla\Plugin\System\Vpsociallogin\Helper\Profile;

\defined('_JEXEC') || die;

/**
 * Base class for standard OAuth2 (authorization-code) providers.
 *
 * Subclasses provide the provider-specific endpoints, scope and the mapping of
 * the user-info payload into a normalized Profile.
 */
abstract class AbstractOAuth2Provider implements ProviderInterface
{
    /**
     * @param string $clientId      OAuth2 client id.
     * @param string $clientSecret  OAuth2 client secret.
     */
    public function __construct(
        protected string $clientId,
        protected string $clientSecret
    ) {
    }

    /* ---------------------------------------------------------------------
     * Provider-specific endpoints / configuration.
     * ------------------------------------------------------------------- */

    /** OAuth2 authorization endpoint. */
    abstract protected function getAuthEndpoint(): string;

    /** OAuth2 token endpoint. */
    abstract protected function getTokenEndpoint(): string;

    /** Space-delimited scope string. */
    abstract protected function getScope(): string;

    /**
     * Fetch the remote user info using the access token and map it to a Profile.
     *
     * @param   string  $accessToken
     *
     * @return  Profile
     */
    abstract protected function mapProfile(string $accessToken): Profile;

    /* ---------------------------------------------------------------------
     * ProviderInterface (shared parts).
     * ------------------------------------------------------------------- */

    public function isRedirectFlow(): bool
    {
        return true;
    }

    public function getAuthorizationUrl(string $state, string $redirectUri): string
    {
        $query = http_build_query(
            array_merge(
                [
                    'client_id'     => $this->clientId,
                    'redirect_uri'  => $redirectUri,
                    'response_type' => 'code',
                    'scope'         => $this->getScope(),
                    'state'         => $state,
                ],
                $this->extraAuthParams()
            )
        );

        return $this->getAuthEndpoint() . '?' . $query;
    }

    public function fetchProfile(array $request, string $redirectUri): Profile
    {
        if (!empty($request['error'])) {
            throw new \RuntimeException('Provider returned an error: ' . (string) $request['error']);
        }

        $code = (string) ($request['code'] ?? '');

        if ($code === '') {
            throw new \RuntimeException('Missing authorization code.');
        }

        $accessToken = $this->exchangeCodeForToken($code, $redirectUri);

        return $this->mapProfile($accessToken);
    }

    /* ---------------------------------------------------------------------
     * Helpers shared by subclasses.
     * ------------------------------------------------------------------- */

    /**
     * Additional provider-specific query parameters for the authorize step.
     *
     * @return array
     */
    protected function extraAuthParams(): array
    {
        return [];
    }

    /**
     * Exchange the authorization code for an access token.
     *
     * @param   string  $code
     * @param   string  $redirectUri
     *
     * @return  string  The access token.
     */
    protected function exchangeCodeForToken(string $code, string $redirectUri): string
    {
        $response = $this->http()->post(
            $this->getTokenEndpoint(),
            [
                'grant_type'    => 'authorization_code',
                'code'          => $code,
                'redirect_uri'  => $redirectUri,
                'client_id'     => $this->clientId,
                'client_secret' => $this->clientSecret,
            ],
            ['Accept' => 'application/json']
        );

        if ($response->code < 200 || $response->code >= 300) {
            throw new \RuntimeException('Token exchange failed (HTTP ' . $response->code . ').');
        }

        $data = json_decode((string) $response->body, true);

        if (!\is_array($data) || empty($data['access_token'])) {
            throw new \RuntimeException('Token endpoint did not return an access token.');
        }

        return (string) $data['access_token'];
    }

    /**
     * Perform an authenticated GET against a JSON API endpoint.
     *
     * @param   string  $url
     * @param   string  $accessToken
     * @param   array   $extraHeaders
     *
     * @return  array
     */
    protected function getJson(string $url, string $accessToken, array $extraHeaders = []): array
    {
        $headers = array_merge(
            [
                'Authorization' => 'Bearer ' . $accessToken,
                'Accept'        => 'application/json',
            ],
            $extraHeaders
        );

        $response = $this->http()->get($url, $headers);

        if ($response->code < 200 || $response->code >= 300) {
            throw new \RuntimeException('Profile request failed (HTTP ' . $response->code . ').');
        }

        $data = json_decode((string) $response->body, true);

        return \is_array($data) ? $data : [];
    }

    /**
     * Shared Joomla HTTP transport.
     *
     * @return \Joomla\Http\Http
     */
    protected function http()
    {
        return (new HttpFactory())->getHttp();
    }
}
