<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Provider;

use Vpjoomla\Plugin\System\Vpsociallogin\Helper\Profile;

\defined('_JEXEC') || die;

/**
 * Sign in with Telegram.
 *
 * Telegram does NOT use OAuth2. It uses the Telegram Login Widget: the browser
 * is redirected back with user data signed via HMAC-SHA256 using a key derived
 * from the bot token. Telegram never returns an e-mail address.
 *
 * The widget itself is rendered by mod_vp_social_login; this class verifies the
 * signed callback and renders the widget markup.
 */
final class TelegramProvider implements ProviderInterface
{
    /**
     * Maximum age (seconds) of the auth_date before the callback is rejected.
     */
    private const MAX_AUTH_AGE = 86400;

    /**
     * @param string $botUsername  Bot username (without the leading @).
     * @param string $botToken     Bot token from @BotFather.
     */
    public function __construct(
        private string $botUsername,
        private string $botToken
    ) {
    }

    public function getKey(): string
    {
        return 'telegram';
    }

    public function getTitle(): string
    {
        return 'Telegram';
    }

    public function getLabel(): string
    {
        return 'PLG_SYSTEM_VPSOCIALLOGIN_LOGIN_TELEGRAM';
    }

    public function isRedirectFlow(): bool
    {
        return false;
    }

    /**
     * Not used: Telegram drives the redirect through its widget.
     *
     * @param   string  $state
     * @param   string  $redirectUri
     *
     * @return  string
     */
    public function getAuthorizationUrl(string $state, string $redirectUri): string
    {
        return '';
    }

    public function fetchProfile(array $request, string $redirectUri): Profile
    {
        $data = array_filter(
            $request,
            static fn ($key) => \in_array(
                $key,
                ['id', 'first_name', 'last_name', 'username', 'photo_url', 'auth_date', 'hash'],
                true
            ),
            ARRAY_FILTER_USE_KEY
        );

        if (empty($data['hash']) || empty($data['id']) || empty($data['auth_date'])) {
            throw new \RuntimeException('Telegram callback is missing required fields.');
        }

        if (!$this->isSignatureValid($data)) {
            throw new \RuntimeException('Telegram data signature is invalid.');
        }

        if ((time() - (int) $data['auth_date']) > self::MAX_AUTH_AGE) {
            throw new \RuntimeException('Telegram authorization has expired.');
        }

        $name = trim(($data['first_name'] ?? '') . ' ' . ($data['last_name'] ?? ''));

        return new Profile(
            provider: $this->getKey(),
            providerUserId: (string) $data['id'],
            // Telegram never returns an e-mail.
            email: null,
            emailVerified: false,
            name: $name !== '' ? $name : (string) ($data['username'] ?? $data['id']),
            username: isset($data['username']) ? (string) $data['username'] : null,
            avatar: isset($data['photo_url']) ? (string) $data['photo_url'] : null
        );
    }

    /**
     * Verify the HMAC-SHA256 signature of the Telegram payload.
     *
     * @param   array  $data  Includes the "hash" field.
     *
     * @return  boolean
     */
    private function isSignatureValid(array $data): bool
    {
        $hash = (string) $data['hash'];
        unset($data['hash']);

        ksort($data);

        $pairs = [];

        foreach ($data as $key => $value) {
            $pairs[] = $key . '=' . $value;
        }

        $checkString = implode("\n", $pairs);
        $secretKey   = hash('sha256', $this->botToken, true);
        $computed    = hash_hmac('sha256', $checkString, $secretKey);

        return hash_equals($computed, $hash);
    }

    /**
     * Render the Telegram Login Widget markup.
     *
     * Uses the callback (data-onauth) mode and performs the redirect to our
     * com_ajax endpoint ourselves. This is deterministic and avoids the
     * data-auth-url / #tgAuthResult fragment fragility of the redirect mode.
     *
     * @param   string  $callbackUrl  Absolute URL of our com_ajax callback.
     * @param   string  $size         small | medium | large.
     *
     * @return  string
     */
    /**
     * Build the Telegram OAuth URL the button redirects to.
     *
     * @param   string  $returnTo  Page Telegram should return to (current page).
     *
     * @return  string
     */
    public function buildAuthUrl(string $returnTo): string
    {
        $botId  = (int) explode(':', $this->botToken)[0];
        $origin = '';

        if ($returnTo !== '' && ($parts = parse_url($returnTo)) && isset($parts['scheme'], $parts['host'])) {
            $origin = $parts['scheme'] . '://' . $parts['host'];

            if (isset($parts['port'])) {
                $origin .= ':' . $parts['port'];
            }
        }

        return 'https://oauth.telegram.org/auth?' . http_build_query(
            [
                'bot_id'         => $botId,
                'origin'         => $origin,
                'return_to'      => $returnTo,
                'request_access' => 'write',
            ],
            '',
            '&',
            PHP_QUERY_RFC3986
        );
    }

    /**
     * Render a standalone Telegram login button (used by mod_vp_social_login).
     *
     * The button redirects to Telegram's OAuth endpoint; on return the shared
     * buttons.js script reads the #tgAuthResult fragment (via data-vpsl-callback)
     * and forwards it to our com_ajax callback.
     *
     * @param   string  $callbackUrl  Absolute com_ajax callback URL.
     * @param   string  $returnTo     Page Telegram should return to (current page).
     * @param   string  $size         Unused (kept for signature compatibility).
     *
     * @return  string
     */
    public function renderWidget(string $callbackUrl, string $returnTo = '', string $size = 'large'): string
    {
        $authAttr     = htmlspecialchars($this->buildAuthUrl($returnTo), ENT_QUOTES, 'UTF-8');
        $callbackAttr = htmlspecialchars($callbackUrl, ENT_QUOTES, 'UTF-8');
        $icon         = $this->getIcon();

        return <<<HTML
<a class="btn btn-secondary w-100 vp-social-login-button vpsl-telegram" href="{$authAttr}" data-vpsl-callback="{$callbackAttr}" rel="nofollow" title="Sign in using your Telegram account">
{$icon}<span class="vp-social-login-button__label">Continue with Telegram</span>
</a>
HTML;
    }

    public function getIcon(): string
    {
        return <<<'SVG'
<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path fill="currentColor" d="M22 3 2 10.8c-1.3.5-1.3 1.3-.2 1.6l5 1.6 2 6c.2.7.1 1 .9 1 .6 0 .9-.3 1.2-.6l2.4-2.3 5 3.7c.9.5 1.6.2 1.8-.9L23.9 4c.3-1.3-.5-1.9-1.9-1zM6.9 13.3l11-7c.5-.3 1-.1.6.2l-9 8.2-.4 3.8-2.2-5.2z"/></svg>
SVG;
    }
}
