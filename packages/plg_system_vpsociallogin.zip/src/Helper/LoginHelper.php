<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Authentication\Authentication;
use Joomla\CMS\Authentication\AuthenticationResponse;
use Joomla\CMS\Event\User\AfterLoginEvent;
use Joomla\CMS\Event\User\LoginEvent;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\User\UserFactoryInterface;

\defined('_JEXEC') || die;

/**
 * Establishes a Joomla session for a user without a password.
 *
 * This mirrors the relevant part of CMSApplication::login(): it dispatches the
 * typed onUserLogin event (handled by plg_user_joomla, which sets the session
 * user and forks the session) and then the onUserAfterLogin event.
 */
final class LoginHelper
{
    public function __construct(private CMSApplicationInterface $app)
    {
    }

    /**
     * Log the given user in.
     *
     * @param   integer  $userId
     *
     * @return  void
     *
     * @throws  \RuntimeException
     */
    public function login(int $userId): void
    {
        $user = Factory::getContainer()->get(UserFactoryInterface::class)->loadUserById($userId);

        if (!$user->id) {
            throw new \RuntimeException('Resolved user could not be loaded.');
        }

        if ($user->block) {
            throw new \RuntimeException('The account is blocked.');
        }

        $response           = new AuthenticationResponse();
        $response->status   = Authentication::STATUS_SUCCESS;
        $response->type     = 'VPSocialLogin';
        $response->username = $user->username;
        $response->email    = $user->email;
        $response->fullname = $user->name;

        $options = [
            'action'   => 'core.login.site',
            'remember' => false,
        ];

        $dispatcher = $this->app->getDispatcher();

        // Import user plugins onto this dispatcher (plg_user_joomla performs the actual login).
        PluginHelper::importPlugin('user', null, true, $dispatcher);

        $loginEvent = new LoginEvent('onUserLogin', ['subject' => (array) $response, 'options' => $options]);
        $dispatcher->dispatch('onUserLogin', $loginEvent);

        $results = $loginEvent->getArgument('result', []) ?: [];

        if (\in_array(false, $results, true)) {
            throw new \RuntimeException('Login was rejected by a user plugin.');
        }

        // Fire the after-login event, exactly as the core login routine does.
        $options['user']         = $user;
        $options['responseType'] = $response->type;

        $dispatcher->dispatch(
            'onUserAfterLogin',
            new AfterLoginEvent('onUserAfterLogin', ['options' => $options, 'subject' => (array) $response])
        );

        // NOTE: do NOT fork the session here. plg_user_joomla::onUserLogin already
        // forks it and sets the session user; forking again breaks the login.
    }
}
