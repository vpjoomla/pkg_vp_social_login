<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\Registry\Registry;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\DiscordProvider;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\GithubProvider;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\GoogleProvider;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\ProviderInterface;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\TelegramProvider;

\defined('_JEXEC') || die;

/**
 * Builds and caches the set of enabled providers based on the plugin parameters.
 */
final class ProviderRegistry
{
    /**
     * @var array<string, ProviderInterface>|null
     */
    private ?array $providers = null;

    public function __construct(
        private Registry $params,
        private CMSApplicationInterface $app
    ) {
    }

    /**
     * Return all enabled providers keyed by provider key.
     *
     * @return array<string, ProviderInterface>
     */
    public function getEnabledProviders(): array
    {
        if ($this->providers !== null) {
            return $this->providers;
        }

        $this->providers = [];

        if ((int) $this->params->get('google_enabled', 0) === 1) {
            $id     = trim((string) $this->params->get('google_client_id', ''));
            $secret = trim((string) $this->params->get('google_client_secret', ''));

            if ($id !== '' && $secret !== '') {
                $this->providers['google'] = new GoogleProvider($id, $secret);
            }
        }

        if ((int) $this->params->get('discord_enabled', 0) === 1) {
            $id     = trim((string) $this->params->get('discord_client_id', ''));
            $secret = trim((string) $this->params->get('discord_client_secret', ''));

            if ($id !== '' && $secret !== '') {
                $this->providers['discord'] = new DiscordProvider($id, $secret);
            }
        }

        if ((int) $this->params->get('github_enabled', 0) === 1) {
            $id     = trim((string) $this->params->get('github_client_id', ''));
            $secret = trim((string) $this->params->get('github_client_secret', ''));

            if ($id !== '' && $secret !== '') {
                $this->providers['github'] = new GithubProvider($id, $secret);
            }
        }

        if ((int) $this->params->get('telegram_enabled', 0) === 1) {
            $user  = trim((string) $this->params->get('telegram_bot_username', ''));
            $token = trim((string) $this->params->get('telegram_bot_token', ''));

            if ($user !== '' && $token !== '') {
                $this->providers['telegram'] = new TelegramProvider($user, $token);
            }
        }

        return $this->providers;
    }

    /**
     * Get a single enabled provider or null.
     *
     * @param   string  $key
     *
     * @return  ProviderInterface|null
     */
    public function getProvider(string $key): ?ProviderInterface
    {
        return $this->getEnabledProviders()[$key] ?? null;
    }
}
