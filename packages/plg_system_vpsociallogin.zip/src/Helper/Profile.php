<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Helper;

\defined('_JEXEC') || die;

/**
 * Provider-agnostic representation of an authenticated remote user.
 */
final class Profile
{
    /**
     * @param string      $provider       Provider key (e.g. "google").
     * @param string      $providerUserId Stable unique id at the provider.
     * @param string|null $email          E-mail address, if available.
     * @param boolean     $emailVerified  Whether the provider asserts the e-mail is verified.
     * @param string|null $name           Display / full name.
     * @param string|null $username       Suggested username (optional).
     * @param string|null $avatar         Avatar URL (optional).
     */
    public function __construct(
        public readonly string $provider,
        public readonly string $providerUserId,
        public readonly ?string $email = null,
        public readonly bool $emailVerified = false,
        public readonly ?string $name = null,
        public readonly ?string $username = null,
        public readonly ?string $avatar = null
    ) {
    }
}
