<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Log\Log;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\TelegramProvider;

\defined('_JEXEC') || die;

/**
 * Drives the social login round-trip: start -> provider -> callback -> login.
 *
 * The anti-CSRF token and the post-login return URL are carried inside the
 * signed OAuth "state" parameter (not the PHP session), so the flow survives
 * SameSite cookie restrictions on the cross-site return from the provider.
 */
final class Authenticator
{
    /**
     * Maximum age (seconds) of a signed state before it is rejected.
     */
    private const STATE_TTL = 900;

    public function __construct(
        private CMSApplicationInterface $app,
        private Registry $params,
        private ProviderRegistry $registry
    ) {
        Log::addLogger(['text_file' => 'vpsociallogin.log.php'], Log::ALL, ['vpsociallogin']);
    }

    /**
     * Start the OAuth2 authorization flow for a redirect-based provider.
     *
     * @param   string  $providerKey
     *
     * @return  void
     */
    public function start(string $providerKey): void
    {
        $provider = $this->registry->getProvider($providerKey);

        if ($provider === null || !$provider->isRedirectFlow()) {
            $this->fail('PLG_SYSTEM_VPSOCIALLOGIN_ERROR_UNKNOWN_PROVIDER', 'Unknown or non-redirect provider: ' . $providerKey);

            return;
        }

        $returnUrl = (string) $this->app->getSession()->get('vpsociallogin.return_url', '');
        $returnUrl = $returnUrl !== '' ? $returnUrl : Uri::root();

        $state = $this->encodeState($returnUrl);

        $this->log('Starting auth for ' . $providerKey);

        $this->app->redirect($provider->getAuthorizationUrl($state, $this->callbackUrl($providerKey)));
    }

    /**
     * Start linking a provider to the currently authenticated user.
     *
     * @param   string  $providerKey
     *
     * @return  void
     */
    public function startLink(string $providerKey): void
    {
        $user = $this->app->getIdentity();

        if (!$user || $user->guest || (int) $user->id <= 0) {
            $this->fail('PLG_SYSTEM_VPSOCIALLOGIN_ERROR_NOT_LOGGED_IN', 'Link requires authentication.');

            return;
        }

        $provider = $this->registry->getProvider($providerKey);

        if ($provider === null) {
            $this->fail('PLG_SYSTEM_VPSOCIALLOGIN_ERROR_UNKNOWN_PROVIDER', 'Unknown provider on link: ' . $providerKey);

            return;
        }

        $returnUrl = (string) $this->app->getSession()->get('vpsociallogin.return_url', '') ?: Uri::root();

        // OAuth2 providers carry the link intent in the signed state. Telegram is
        // not started here — its connect button goes straight to Telegram's OAuth
        // and carries a signed link token in the callback URL (see the user plugin).
        if ($provider->isRedirectFlow()) {
            $this->log('Starting LINK for ' . $providerKey . ' user=' . $user->id);
            $this->app->redirect(
                $provider->getAuthorizationUrl($this->encodeState($returnUrl, true), $this->callbackUrl($providerKey))
            );

            return;
        }

        $this->fail('PLG_SYSTEM_VPSOCIALLOGIN_ERROR_UNKNOWN_PROVIDER', 'Provider cannot be linked here: ' . $providerKey);
    }

    /**
     * Remove a provider link from the currently authenticated user.
     *
     * @param   string  $providerKey
     *
     * @return  void
     */
    public function unlink(string $providerKey): void
    {
        $user = $this->app->getIdentity();

        if (!$user || $user->guest || (int) $user->id <= 0) {
            $this->fail('PLG_SYSTEM_VPSOCIALLOGIN_ERROR_NOT_LOGGED_IN', 'Unlink requires authentication.');

            return;
        }

        $returnUrl  = (string) $this->app->getSession()->get('vpsociallogin.return_url', '') ?: Uri::root();
        $userHelper = new UserHelper($this->app, $this->params);

        if (!$userHelper->canUnlink((int) $user->id, $providerKey)) {
            $this->app->enqueueMessage(Text::_('PLG_SYSTEM_VPSOCIALLOGIN_ERROR_UNLINK_LAST'), 'warning');
            $this->app->redirect($this->safeReturn($returnUrl));

            return;
        }

        $userHelper->unlink((int) $user->id, $providerKey);
        $this->log('Unlinked ' . $providerKey . ' from user id=' . $user->id);

        $this->app->enqueueMessage(
            Text::sprintf('PLG_SYSTEM_VPSOCIALLOGIN_UNLINK_SUCCESS', ucfirst($providerKey)),
            'message'
        );

        $this->app->redirect($this->safeReturn($returnUrl));
    }

    /**
     * Handle the provider callback, then log the user in.
     *
     * @param   string  $providerKey
     *
     * @return  void
     */
    public function callback(string $providerKey): void
    {
        $provider = $this->registry->getProvider($providerKey);

        if ($provider === null) {
            $this->fail('PLG_SYSTEM_VPSOCIALLOGIN_ERROR_UNKNOWN_PROVIDER', 'Unknown provider on callback: ' . $providerKey);

            return;
        }

        $input      = $this->app->getInput();
        $returnUrl  = Uri::root();
        $isLink     = false;
        $linkUserId = 0;

        try {
            // Redirect (OAuth2) providers carry our signed state; verify it.
            if ($provider->isRedirectFlow()) {
                $state     = $this->decodeState($input->getString('state', ''));
                $returnUrl = $state['r'];
                $isLink    = $state['l'];
                $request   = $input->getArray();

                if ($isLink) {
                    $current    = $this->app->getIdentity();
                    $linkUserId = ($current && !$current->guest) ? (int) $current->id : 0;
                }
            } else {
                // Telegram: read fields RAW (Joomla's default filtering would
                // mangle values and break the HMAC), and take the return URL
                // from the session. Link mode is carried by a signed token
                // (session-independent), not the session itself.
                $returnUrl = (string) $this->app->getSession()->get('vpsociallogin.return_url', '') ?: Uri::root();

                $linkToken = $input->getString('vpsl_link', '');

                if ($linkToken !== '') {
                    $tokenUserId = LinkToken::verify($linkToken);

                    if ($tokenUserId !== null) {
                        $isLink     = true;
                        $linkUserId = $tokenUserId;
                    }
                }

                $request = [];

                foreach (['id', 'first_name', 'last_name', 'username', 'photo_url', 'auth_date', 'hash'] as $field) {
                    $value = $input->get($field, null, 'raw');

                    if ($value !== null && $value !== '') {
                        $request[$field] = $value;
                    }
                }
            }

            $this->log('Callback for ' . $providerKey . ': fetching profile (link=' . ($isLink ? '1' : '0') . ')');
            $profile = $provider->fetchProfile($request, $this->callbackUrl($providerKey));

            $this->log('Profile resolved: ' . $profile->provider . ' / id=' . $profile->providerUserId
                . ' / email=' . ($profile->email ?? '-') . ' / verified=' . ($profile->emailVerified ? '1' : '0'));

            $userHelper = new UserHelper($this->app, $this->params);

            if ($isLink) {
                if ($linkUserId <= 0) {
                    throw new \RuntimeException('You must be logged in to connect an account.');
                }

                $userHelper->link($linkUserId, $profile);

                $this->app->enqueueMessage(
                    Text::sprintf('PLG_SYSTEM_VPSOCIALLOGIN_LINK_SUCCESS', ucfirst($providerKey)),
                    'message'
                );

                $this->log('Linked ' . $providerKey . ' to user id=' . $linkUserId);
            } else {
                $userId = $userHelper->findOrCreate($profile);

                $this->log('Resolved user id=' . $userId . '; logging in');
                (new LoginHelper($this->app))->login($userId);

                $this->log('Login OK for user id=' . $userId . '; redirecting to ' . $returnUrl);
            }
        } catch (\Throwable $e) {
            $this->log('Callback failed (' . $providerKey . '): ' . $e->getMessage(), Log::ERROR);

            if ($isLink) {
                $messageKey = $e->getCode() === 409
                    ? 'PLG_SYSTEM_VPSOCIALLOGIN_ERROR_LINK_TAKEN'
                    : 'PLG_SYSTEM_VPSOCIALLOGIN_ERROR_LINK_FAILED';
            } else {
                $messageKey = $e->getCode() === 409
                    ? 'PLG_SYSTEM_VPSOCIALLOGIN_ERROR_EMAIL_EXISTS'
                    : 'PLG_SYSTEM_VPSOCIALLOGIN_ERROR_LOGIN_FAILED';
            }

            $this->fail($messageKey, $e->getMessage());

            return;
        }

        $this->app->getSession()->clear('vpsociallogin.return_url');
        $this->app->redirect($this->safeReturn($returnUrl));
    }

    /* ---------------------------------------------------------------------
     * Signed state (self-contained CSRF token + return URL).
     * ------------------------------------------------------------------- */

    /**
     * Build a signed state token embedding the return URL.
     *
     * @param   string  $returnUrl
     *
     * @return  string
     */
    private function encodeState(string $returnUrl, bool $link = false): string
    {
        $payload = $this->b64UrlEncode((string) json_encode([
            'n' => bin2hex(random_bytes(8)),
            'r' => $returnUrl,
            'l' => $link ? 1 : 0,
            't' => time(),
        ]));

        $signature = $this->b64UrlEncode(hash_hmac('sha256', $payload, $this->secret(), true));

        return $payload . '.' . $signature;
    }

    /**
     * Verify a signed state and return its embedded data.
     *
     * @param   string  $state
     *
     * @return  array{r:string,l:bool}
     *
     * @throws  \RuntimeException
     */
    private function decodeState(string $state): array
    {
        $parts = explode('.', $state, 2);

        if (\count($parts) !== 2 || $parts[0] === '' || $parts[1] === '') {
            throw new \RuntimeException('Malformed state.');
        }

        [$payload, $signature] = $parts;

        $expected = $this->b64UrlEncode(hash_hmac('sha256', $payload, $this->secret(), true));

        if (!hash_equals($expected, $signature)) {
            throw new \RuntimeException('State signature mismatch (possible CSRF).');
        }

        $data = json_decode($this->b64UrlDecode($payload), true);

        if (!\is_array($data) || !isset($data['t'])) {
            throw new \RuntimeException('Invalid state payload.');
        }

        if ((time() - (int) $data['t']) > self::STATE_TTL) {
            throw new \RuntimeException('State expired.');
        }

        return [
            'r' => (string) ($data['r'] ?? Uri::root()),
            'l' => (bool) ($data['l'] ?? false),
        ];
    }

    /**
     * Server-side signing secret (Joomla global secret).
     *
     * @return string
     */
    private function secret(): string
    {
        return (string) $this->app->get('secret', 'vpsociallogin');
    }

    private function b64UrlEncode(string $bin): string
    {
        return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
    }

    private function b64UrlDecode(string $text): string
    {
        return (string) base64_decode(strtr($text, '-_', '+/'));
    }

    /* ---------------------------------------------------------------------
     * URLs, redirects, logging.
     * ------------------------------------------------------------------- */

    /**
     * Absolute, stable callback URL for a provider (must match the registered redirect URI).
     *
     * @param   string  $providerKey
     *
     * @return  string
     */
    private function callbackUrl(string $providerKey): string
    {
        return Uri::root()
            . 'index.php?option=com_ajax&group=system&plugin=vpsociallogin&format=raw'
            . '&vpsl=callback&provider=' . urlencode($providerKey);
    }

    /**
     * Only allow returning to URLs on this site.
     *
     * @param   string  $return
     *
     * @return  string
     */
    private function safeReturn(string $return): string
    {
        $root = Uri::root();

        // Reject empty values and off-site URLs (open-redirect guard).
        if ($return === '' || !str_starts_with($return, $root)) {
            return $root;
        }

        // Never send a freshly logged-in user back to the login page.
        $path = strtolower(substr($return, strlen($root)));

        if (
            $path === 'login'
            || str_starts_with($path, 'login?')
            || str_starts_with($path, 'login/')
            || str_contains($path, 'view=login')
            || str_contains($path, 'task=user.login')
        ) {
            return $root;
        }

        return $return;
    }

    /**
     * Enqueue an error and redirect back to the site.
     *
     * @param   string  $messageKey
     * @param   string  $detail      Technical detail, shown only in debug mode.
     *
     * @return  void
     */
    private function fail(string $messageKey, string $detail = ''): void
    {
        $message = Text::_($messageKey);

        if ($detail !== '' && (int) $this->params->get('debug', 0) === 1) {
            $message .= ' [' . $detail . ']';
        }

        $this->app->enqueueMessage($message, 'error');
        $this->app->redirect(Uri::root());
    }

    /**
     * Write to the dedicated log channel.
     *
     * @param   string   $message
     * @param   integer  $priority
     *
     * @return  void
     */
    private function log(string $message, int $priority = Log::INFO): void
    {
        Log::add($message, $priority, 'vpsociallogin');
    }
}
