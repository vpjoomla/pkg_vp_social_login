<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\User\User;
use Joomla\CMS\User\UserHelper as JoomlaUserHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;

\defined('_JEXEC') || die;

/**
 * Resolves a normalized social Profile to a local Joomla user id,
 * creating and/or linking the account as configured.
 */
final class UserHelper
{
    private DatabaseInterface $db;

    public function __construct(
        private CMSApplicationInterface $app,
        private Registry $params
    ) {
        $this->db = Factory::getContainer()->get(DatabaseInterface::class);
    }

    /**
     * Find (or create) the Joomla user matching the given social profile.
     *
     * @param   Profile  $profile
     *
     * @return  integer  The Joomla user id.
     *
     * @throws  \RuntimeException
     */
    public function findOrCreate(Profile $profile): int
    {
        // 1) Existing explicit link?
        $linkedId = $this->findLinkedUserId($profile);

        if ($linkedId > 0) {
            return $linkedId;
        }

        // 2) Match an existing account by verified e-mail (if allowed).
        if (
            (int) $this->params->get('link_by_email', 1) === 1
            && $profile->email
            && $profile->emailVerified
        ) {
            $existingId = $this->findUserIdByEmail($profile->email);

            if ($existingId > 0) {
                $this->storeLink($existingId, $profile);

                return $existingId;
            }
        }

        // 3) Auto-register a new account.
        if ((int) $this->params->get('auto_register', 1) === 1) {
            // Never create a duplicate: if the e-mail is already taken but we did
            // not auto-link above (linking disabled, or e-mail not verified), stop
            // with a clear conflict instead of failing on a DB unique constraint.
            if ($profile->email && $this->findUserIdByEmail($profile->email) > 0) {
                throw new \RuntimeException('An account with this e-mail already exists.', 409);
            }

            $userId = $this->createUser($profile);
            $this->storeLink($userId, $profile);

            return $userId;
        }

        throw new \RuntimeException('No linked account and auto-registration is disabled.');
    }

    /**
     * Look up the user id linked to this provider identity.
     *
     * @param   Profile  $profile
     *
     * @return  integer
     */
    private function findLinkedUserId(Profile $profile): int
    {
        // bind() takes values by reference, so use locals (not readonly props / call results).
        $key = $this->linkKey($profile->provider);
        $val = $profile->providerUserId;

        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('user_id'))
            ->from($this->db->quoteName('#__user_profiles'))
            ->where($this->db->quoteName('profile_key') . ' = :key')
            ->where($this->db->quoteName('profile_value') . ' = :val')
            ->bind(':key', $key)
            ->bind(':val', $val);

        $this->db->setQuery($query);

        return (int) ($this->db->loadResult() ?? 0);
    }

    /**
     * Find an active local user id by e-mail.
     *
     * @param   string  $email
     *
     * @return  integer
     */
    private function findUserIdByEmail(string $email): int
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('id'))
            ->from($this->db->quoteName('#__users'))
            ->where('LOWER(' . $this->db->quoteName('email') . ') = LOWER(:email)')
            ->bind(':email', $email)
            ->setLimit(1);

        $this->db->setQuery($query);

        return (int) ($this->db->loadResult() ?? 0);
    }

    /**
     * Create a brand-new Joomla user from the profile.
     *
     * @param   Profile  $profile
     *
     * @return  integer
     *
     * @throws  \RuntimeException
     */
    private function createUser(Profile $profile): int
    {
        $email = $profile->email ?: $this->syntheticEmail($profile);
        $name  = $profile->name ?: ($profile->username ?: $profile->provider . ' user');
        $group = (int) $this->params->get('new_user_group', 2) ?: 2;

        $password = JoomlaUserHelper::genRandomPassword(32);

        $data = [
            'name'      => $name,
            'username'  => $this->uniqueUsername($profile),
            'email'     => $email,
            'password'  => $password,
            'password2' => $password,
            'groups'    => [$group],
            'block'     => 0,
        ];

        $user = new User();

        if (!$user->bind($data)) {
            throw new \RuntimeException('Unable to bind new user data: ' . $user->getError());
        }

        if (!$user->save()) {
            throw new \RuntimeException('Unable to create user: ' . $user->getError());
        }

        return (int) $user->id;
    }

    /**
     * Persist the provider identity -> user link.
     *
     * @param   integer  $userId
     * @param   Profile  $profile
     *
     * @return  void
     */
    private function storeLink(int $userId, Profile $profile): void
    {
        $key = $this->linkKey($profile->provider);

        // Remove any stale row for this user + key, then insert a fresh one.
        $delete = $this->db->getQuery(true)
            ->delete($this->db->quoteName('#__user_profiles'))
            ->where($this->db->quoteName('user_id') . ' = :uid')
            ->where($this->db->quoteName('profile_key') . ' = :key')
            ->bind(':uid', $userId, \Joomla\Database\ParameterType::INTEGER)
            ->bind(':key', $key);
        $this->db->setQuery($delete)->execute();

        $row = (object) [
            'user_id'       => $userId,
            'profile_key'   => $key,
            'profile_value' => $profile->providerUserId,
            'ordering'      => 0,
        ];

        $this->db->insertObject('#__user_profiles', $row);
    }

    /**
     * Return the provider keys currently linked to a user (e.g. ['google','telegram']).
     *
     * @param   integer  $userId
     *
     * @return  string[]
     */
    public function getLinkedProviders(int $userId): array
    {
        $like  = 'vpsociallogin.%.id';
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('profile_key'))
            ->from($this->db->quoteName('#__user_profiles'))
            ->where($this->db->quoteName('user_id') . ' = :uid')
            ->where($this->db->quoteName('profile_key') . ' LIKE :like')
            ->bind(':uid', $userId, \Joomla\Database\ParameterType::INTEGER)
            ->bind(':like', $like);

        $this->db->setQuery($query);

        $providers = [];

        foreach (($this->db->loadColumn() ?: []) as $key) {
            if (preg_match('/^vpsociallogin\.([a-z0-9_]+)\.id$/i', (string) $key, $m)) {
                $providers[] = $m[1];
            }
        }

        return $providers;
    }

    /**
     * Link a social identity to an existing (already authenticated) user.
     *
     * @param   integer  $userId
     * @param   Profile  $profile
     *
     * @return  void
     *
     * @throws  \RuntimeException  If the identity is already linked to another user (code 409).
     */
    public function link(int $userId, Profile $profile): void
    {
        $owner = $this->findLinkedUserId($profile);

        if ($owner > 0 && $owner !== $userId) {
            // If the previous owner still exists, the identity is genuinely taken.
            if ($this->userExists($owner)) {
                throw new \RuntimeException('This account is already connected to another user.', 409);
            }

            // The previous owner was deleted — remove the orphaned link so the
            // current user can claim this identity.
            $this->unlink($owner, $profile->provider);
        }

        $this->storeLink($userId, $profile);
    }

    /**
     * Whether a user id still exists.
     *
     * @param   integer  $userId
     *
     * @return  boolean
     */
    private function userExists(int $userId): bool
    {
        $query = $this->db->getQuery(true)
            ->select('1')
            ->from($this->db->quoteName('#__users'))
            ->where($this->db->quoteName('id') . ' = :uid')
            ->bind(':uid', $userId, \Joomla\Database\ParameterType::INTEGER);

        $this->db->setQuery($query, 0, 1);

        return (bool) $this->db->loadResult();
    }

    /**
     * Remove a provider link from a user.
     *
     * @param   integer  $userId
     * @param   string   $provider
     *
     * @return  void
     */
    public function unlink(int $userId, string $provider): void
    {
        $key   = $this->linkKey($provider);
        $query = $this->db->getQuery(true)
            ->delete($this->db->quoteName('#__user_profiles'))
            ->where($this->db->quoteName('user_id') . ' = :uid')
            ->where($this->db->quoteName('profile_key') . ' = :key')
            ->bind(':uid', $userId, \Joomla\Database\ParameterType::INTEGER)
            ->bind(':key', $key);

        $this->db->setQuery($query)->execute();
    }

    /**
     * Whether the user would still have a way to sign in after removing $provider.
     *
     * A user is safe to unlink if they keep at least one other linked provider, or
     * if they have a real (non-synthetic) e-mail and can therefore reset a password.
     * Accounts created via Telegram (synthetic vpsl- e-mail, no known password) are
     * protected from removing their last remaining provider.
     *
     * @param   integer  $userId
     * @param   string   $provider
     *
     * @return  boolean
     */
    public function canUnlink(int $userId, string $provider): bool
    {
        $remaining = array_filter(
            $this->getLinkedProviders($userId),
            static fn (string $p): bool => $p !== $provider
        );

        if (!empty($remaining)) {
            return true;
        }

        $email = strtolower($this->userEmail($userId));

        return $email !== '' && !str_starts_with($email, 'vpsl-');
    }

    /**
     * Fetch a user's e-mail.
     *
     * @param   integer  $userId
     *
     * @return  string
     */
    private function userEmail(int $userId): string
    {
        $query = $this->db->getQuery(true)
            ->select($this->db->quoteName('email'))
            ->from($this->db->quoteName('#__users'))
            ->where($this->db->quoteName('id') . ' = :uid')
            ->bind(':uid', $userId, \Joomla\Database\ParameterType::INTEGER);

        $this->db->setQuery($query);

        return (string) ($this->db->loadResult() ?? '');
    }

    /**
     * Build the #__user_profiles key for a provider link.
     *
     * @param   string  $provider
     *
     * @return  string
     */
    private function linkKey(string $provider): string
    {
        return 'vpsociallogin.' . $provider . '.id';
    }

    /**
     * Generate a deterministic, unique synthetic e-mail for providers without one (Telegram).
     *
     * @param   Profile  $profile
     *
     * @return  string
     */
    private function syntheticEmail(Profile $profile): string
    {
        $host = \Joomla\CMS\Uri\Uri::getInstance()->getHost() ?: 'example.com';

        return 'vpsl-' . $profile->provider . '-' . $profile->providerUserId . '@' . $host;
    }

    /**
     * Build a unique username from the profile.
     *
     * @param   Profile  $profile
     *
     * @return  string
     */
    private function uniqueUsername(Profile $profile): string
    {
        $base = $profile->username
            ?: ($profile->email ? strstr($profile->email, '@', true) : $profile->provider . $profile->providerUserId);

        $base = preg_replace('/[^A-Za-z0-9._-]/', '', (string) $base);
        $base = $base !== '' ? $base : ($profile->provider . $profile->providerUserId);

        $candidate = $base;
        $suffix    = 0;

        while ($this->usernameExists($candidate)) {
            $suffix++;
            $candidate = $base . $suffix;
        }

        return $candidate;
    }

    /**
     * Whether a username already exists.
     *
     * @param   string  $username
     *
     * @return  boolean
     */
    private function usernameExists(string $username): bool
    {
        $query = $this->db->getQuery(true)
            ->select('COUNT(*)')
            ->from($this->db->quoteName('#__users'))
            ->where($this->db->quoteName('username') . ' = :username')
            ->bind(':username', $username);

        $this->db->setQuery($query);

        return (int) $this->db->loadResult() > 0;
    }
}
