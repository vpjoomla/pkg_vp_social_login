<?php

/**
 * @package     VP Social Login
 * @subpackage  System.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\System\Vpsociallogin\Helper;

use Joomla\CMS\Factory;

\defined('_JEXEC') || die;

/**
 * Short-lived, signed token that carries an "account link" intent for a specific
 * user across the Telegram OAuth round-trip — without relying on the session
 * (which does not survive the cross-site return under SameSite cookies).
 */
final class LinkToken
{
    private const TTL = 900;

    /**
     * Create a signed link token for a user.
     *
     * @param   integer  $userId
     *
     * @return  string
     */
    public static function sign(int $userId): string
    {
        $payload = self::b64UrlEncode((string) json_encode([
            'u' => $userId,
            'n' => bin2hex(random_bytes(8)),
            't' => time(),
        ]));

        $signature = self::b64UrlEncode(hash_hmac('sha256', $payload, self::secret(), true));

        return $payload . '.' . $signature;
    }

    /**
     * Verify a signed link token and return the user id, or null if invalid/expired.
     *
     * @param   string  $token
     *
     * @return  integer|null
     */
    public static function verify(string $token): ?int
    {
        $parts = explode('.', $token, 2);

        if (\count($parts) !== 2 || $parts[0] === '' || $parts[1] === '') {
            return null;
        }

        [$payload, $signature] = $parts;

        $expected = self::b64UrlEncode(hash_hmac('sha256', $payload, self::secret(), true));

        if (!hash_equals($expected, $signature)) {
            return null;
        }

        $data = json_decode(self::b64UrlDecode($payload), true);

        if (!\is_array($data) || !isset($data['t'], $data['u'])) {
            return null;
        }

        if ((time() - (int) $data['t']) > self::TTL) {
            return null;
        }

        return (int) $data['u'] > 0 ? (int) $data['u'] : null;
    }

    /**
     * @return  string
     */
    private static function secret(): string
    {
        return (string) Factory::getApplication()->get('secret');
    }

    /**
     * @param   string  $data
     *
     * @return  string
     */
    private static function b64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * @param   string  $data
     *
     * @return  string
     */
    private static function b64UrlDecode(string $data): string
    {
        return (string) base64_decode(strtr($data, '-_', '+/'), true);
    }
}
