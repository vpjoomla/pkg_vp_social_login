/**
 * VP Social Login - button navigation and Telegram return handling.
 *
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 */
(function () {
    'use strict';

    // 1) OAuth buttons: redirect to the provider start URL on click.
    document.addEventListener('click', function (event) {
        var button = event.target.closest('.vp-social-login-button[data-vpsl-url]');

        if (!button) {
            return;
        }

        event.preventDefault();

        var url = button.getAttribute('data-vpsl-url');

        if (url) {
            window.location.assign(url);
        }
    });

    // 2) Telegram return: decode the #tgAuthResult fragment and forward it to
    //    our com_ajax callback (read from the Telegram button's data attribute).
    (function handleTelegramReturn() {
        var hash   = window.location.hash || '';
        var marker = 'tgAuthResult=';

        if (hash.indexOf(marker) === -1) {
            return;
        }

        var holder = document.querySelector('[data-vpsl-callback]');

        if (!holder) {
            return;
        }

        try {
            var b64 = hash.substring(hash.indexOf(marker) + marker.length)
                .replace(/-/g, '+').replace(/_/g, '/');

            while (b64.length % 4) {
                b64 += '=';
            }

            var user = JSON.parse(decodeURIComponent(escape(window.atob(b64))));
            var url  = new URL(holder.getAttribute('data-vpsl-callback'));

            Object.keys(user).forEach(function (key) {
                if (user[key] !== undefined && user[key] !== null) {
                    url.searchParams.set(key, user[key]);
                }
            });

            window.location.href = url.toString();
        } catch (e) {
            window.console && window.console.error('[VPSL Telegram] fragment:', e);
        }
    })();
})();
