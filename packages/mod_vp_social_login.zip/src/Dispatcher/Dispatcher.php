<?php

/**
 * @package     VP Social Login
 * @subpackage  mod_vp_social_login
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Module\VpSocialLogin\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Dispatcher class for mod_vp_social_login.
 */
class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    /**
     * Returns the layout data.
     *
     * @return array
     */
    protected function getLayoutData()
    {
        $data = parent::getLayoutData();

        $helper = $this->getHelperFactory()->getHelper('VpSocialLoginHelper');
        $view   = $helper->getViewData($data['params'], $this->getApplication());

        $data['providers']      = $view['providers'];
        $data['telegramWidget'] = $view['telegramWidget'];
        $data['styleClass']     = $view['styleClass'];
        $data['directionClass'] = $view['directionClass'];
        $data['isGuest']        = $view['isGuest'];

        return $data;
    }
}
