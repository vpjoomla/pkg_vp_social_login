<?php

/**
 * @package     VP Social Login
 * @subpackage  mod_vp_social_login
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Module\VpSocialLogin\Site\Helper;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;
use Vpjoomla\Plugin\System\Vpsociallogin\Helper\ProviderRegistry;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\TelegramProvider;

\defined('_JEXEC') || die;

/**
 * Builds the data the module template needs, reusing the system plugin's
 * provider configuration (the plugin must be installed and enabled).
 */
class VpSocialLoginHelper
{
    /**
     * Assemble the view data for the module layout.
     *
     * @param   Registry         $moduleParams
     * @param   SiteApplication  $app
     *
     * @return  array
     */
    public function getViewData(Registry $moduleParams, SiteApplication $app): array
    {
        $isGuest = $app->getIdentity() === null || $app->getIdentity()->guest;

        $view = [
            'providers'      => [],
            'telegramWidget' => null,
            'isGuest'        => $isGuest,
            'styleClass'     => 'vp-social-login--brand',
            'directionClass' => $moduleParams->get('layout_direction', 'column') === 'inline'
                ? 'vp-social-login--inline'
                : '',
        ];

        // Nothing to render for logged-in users, or if the engine plugin is unavailable.
        if (!$isGuest || !PluginHelper::isEnabled('system', 'vpsociallogin') || !class_exists(ProviderRegistry::class)) {
            return $view;
        }

        $pluginParams = $this->getPluginParams();

        // Make the plugin's PLG_* button labels available in this module context.
        $app->getLanguage()->load('plg_system_vpsociallogin', JPATH_PLUGINS . '/system/vpsociallogin');

        // Resolve the effective button style (module overrides plugin unless "inherit").
        $style = $moduleParams->get('button_style', 'inherit');

        if ($style === 'inherit') {
            $style = $pluginParams->get('button_style', 'brand');
        }

        $view['styleClass'] = 'vp-social-login--' . preg_replace('/[^a-z]/', '', (string) $style);

        $registry = new ProviderRegistry($pluginParams, $app);

        foreach ($registry->getEnabledProviders() as $provider) {
            if ($provider->isRedirectFlow()) {
                $view['providers'][] = [
                    'key'   => $provider->getKey(),
                    'title' => $provider->getTitle(),
                    'label' => $provider->getLabel(),
                    'icon'  => $provider->getIcon(),
                    'url'   => $this->startUrl($provider->getKey()),
                ];

                continue;
            }

            if ($provider instanceof TelegramProvider) {
                $view['telegramWidget'] = $provider->renderWidget($this->callbackUrl('telegram'), Uri::current());
            }
        }

        if (!empty($view['providers']) || $view['telegramWidget'] !== null) {
            $app->getSession()->set('vpsociallogin.return_url', Uri::current());
            $this->loadAssets($app);
        }

        return $view;
    }

    /**
     * Load the system plugin's configuration as a Registry.
     *
     * @return Registry
     */
    private function getPluginParams(): Registry
    {
        $plugin = PluginHelper::getPlugin('system', 'vpsociallogin');

        return new Registry($plugin->params ?? '{}');
    }

    /**
     * Build the auth-start URL for a redirect provider.
     *
     * @param   string  $key
     *
     * @return  string
     */
    private function startUrl(string $key): string
    {
        return Uri::root()
            . 'index.php?option=com_ajax&group=system&plugin=vpsociallogin&format=raw'
            . '&vpsl=auth&provider=' . urlencode($key);
    }

    /**
     * Build the callback URL for a provider (used by the Telegram widget).
     *
     * @param   string  $key
     *
     * @return  string
     */
    private function callbackUrl(string $key): string
    {
        return Uri::root()
            . 'index.php?option=com_ajax&group=system&plugin=vpsociallogin&format=raw'
            . '&vpsl=callback&provider=' . urlencode($key);
    }

    /**
     * Register the shared plugin assets.
     *
     * @param   SiteApplication  $app
     *
     * @return  void
     */
    private function loadAssets(SiteApplication $app): void
    {
        $wa = $app->getDocument()->getWebAssetManager();

        $wa->registerAndUseStyle('plg_system_vpsociallogin.buttons', 'plg_system_vpsociallogin/vpsociallogin.css');
        $wa->registerAndUseScript(
            'plg_system_vpsociallogin.buttons',
            'plg_system_vpsociallogin/buttons.js',
            [],
            ['defer' => true]
        );
    }
}
