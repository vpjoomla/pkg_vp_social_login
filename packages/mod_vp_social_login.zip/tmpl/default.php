<?php

/**
 * @package     VP Social Login
 * @subpackage  mod_vp_social_login
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 *
 * @var \Joomla\Registry\Registry $params          Module parameters.
 * @var array                     $providers       Redirect (OAuth2) providers.
 * @var string|null               $telegramWidget  Telegram widget markup, if enabled.
 * @var string                    $styleClass      Style wrapper class.
 * @var string                    $directionClass  Layout direction class.
 * @var boolean                   $isGuest         Whether the current user is a guest.
 */

use Joomla\CMS\Language\Text;

\defined('_JEXEC') || die;

if (!$isGuest) {
    if ((int) $params->get('logged_in_notice', 0) === 1) {
        echo '<p class="vp-social-login__notice">' . Text::_('MOD_VP_SOCIAL_LOGIN_ALREADY_LOGGED_IN') . '</p>';
    }

    return;
}

if (empty($providers) && empty($telegramWidget)) {
    return;
}

$wrapperClass = trim('vp-social-login ' . $styleClass . ' ' . $directionClass);
?>
<div class="<?php echo htmlspecialchars($wrapperClass, ENT_QUOTES, 'UTF-8'); ?>">
	<?php foreach ($providers as $provider) :
		$url = htmlspecialchars($provider['url'], ENT_QUOTES, 'UTF-8');
		?>
		<a class="btn btn-secondary w-100 vp-social-login-button vpsl-<?php echo htmlspecialchars($provider['key'], ENT_QUOTES, 'UTF-8'); ?>"
		   href="<?php echo $url; ?>"
		   data-vpsl-url="<?php echo $url; ?>"
		   rel="nofollow"
		   title="<?php echo htmlspecialchars(Text::sprintf('PLG_SYSTEM_VPSOCIALLOGIN_BTN_TOOLTIP', $provider['title']), ENT_QUOTES, 'UTF-8'); ?>">
			<?php echo $provider['icon']; ?>
			<span class="vp-social-login-button__label"><?php echo Text::_($provider['label']); ?></span>
		</a>
	<?php endforeach; ?>

	<?php if (!empty($telegramWidget)) : ?>
		<div class="vp-social-login__telegram">
			<?php echo $telegramWidget; ?>
		</div>
	<?php endif; ?>
</div>
