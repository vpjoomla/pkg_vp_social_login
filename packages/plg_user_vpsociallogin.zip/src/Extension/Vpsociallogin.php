<?php

/**
 * @package     VP Social Login
 * @subpackage  User.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\User\Vpsociallogin\Extension;

use Joomla\CMS\Event\Model\PrepareFormEvent;
use Joomla\CMS\Event\User\AfterDeleteEvent;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Event\SubscriberInterface;
use Joomla\Utilities\ArrayHelper;

\defined('_JEXEC') || die;

/**
 * Adds a "Connected accounts" section to the user profile edit form, where the
 * user can connect/disconnect social providers. The heavy lifting (the actual
 * link/unlink round-trip) is handled by plg_system_vpsociallogin via com_ajax.
 */
final class Vpsociallogin extends CMSPlugin implements SubscriberInterface, DatabaseAwareInterface
{
    use DatabaseAwareTrait;

    /**
     * @inheritDoc
     */
    public static function getSubscribedEvents(): array
    {
        return [
            'onContentPrepareForm' => 'onContentPrepareForm',
            'onUserAfterDelete'    => 'onUserAfterDelete',
        ];
    }

    /**
     * Inject the connected-accounts fieldset into the front-end profile form.
     *
     * @param   PrepareFormEvent  $event
     *
     * @return  void
     */
    public function onContentPrepareForm(PrepareFormEvent $event): void
    {
        $form = $event->getForm();

        // Only the site profile edit form (a logged-in user managing their own account).
        if ($form->getName() !== 'com_users.profile') {
            return;
        }

        $this->loadLanguage();

        FormHelper::addFieldPrefix('Vpjoomla\\Plugin\\User\\Vpsociallogin\\Field');
        FormHelper::addFormPath(JPATH_PLUGINS . '/' . $this->_type . '/' . $this->_name . '/forms');

        $form->loadFile('connected');
    }

    /**
     * Remove all VP Social Login links when a user is deleted, so no orphaned
     * rows are left behind in #__user_profiles (which would otherwise block a
     * future account from claiming the same social identity).
     *
     * @param   AfterDeleteEvent  $event
     *
     * @return  void
     */
    public function onUserAfterDelete(AfterDeleteEvent $event): void
    {
        if (!$event->getDeletingResult()) {
            return;
        }

        $userId = ArrayHelper::getValue($event->getUser(), 'id', 0, 'int');

        if (!$userId) {
            return;
        }

        try {
            $db    = $this->getDatabase();
            $query = $db->getQuery(true)
                ->delete($db->quoteName('#__user_profiles'))
                ->where($db->quoteName('user_id') . ' = :userid')
                ->where($db->quoteName('profile_key') . ' LIKE ' . $db->quote('vpsociallogin.%'))
                ->bind(':userid', $userId, ParameterType::INTEGER);

            $db->setQuery($query);
            $db->execute();
        } catch (\Throwable $e) {
            // The user was already deleted; cleaning up the links is best-effort.
        }
    }
}
