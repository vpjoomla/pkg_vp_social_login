<?php

/**
 * @package     VP Social Login
 * @subpackage  User.vpsociallogin
 * @author      Volodymyr Pershyn
 * @copyright   Copyright (C) 2024 - 2026 VPJoomla. All rights reserved.
 * @license     GNU GPL v2 or later; see LICENSE.txt
 * @link        https://vpjoomla.com
 */

namespace Vpjoomla\Plugin\User\Vpsociallogin\Field;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Session\Session;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;
use Vpjoomla\Plugin\System\Vpsociallogin\Helper\LinkToken;
use Vpjoomla\Plugin\System\Vpsociallogin\Helper\ProviderRegistry;
use Vpjoomla\Plugin\System\Vpsociallogin\Helper\UserHelper;
use Vpjoomla\Plugin\System\Vpsociallogin\Provider\TelegramProvider;

\defined('_JEXEC') || die;

/**
 * Renders the "Connected accounts" block on the user profile edit page.
 */
class VpslconnectedField extends FormField
{
    /**
     * @var string
     */
    protected $type = 'Vpslconnected';

    /**
     * Render the whole block full-width (no separate label column).
     *
     * @param   array  $options
     *
     * @return  string
     */
    public function renderField($options = []): string
    {
        return $this->getInput();
    }

    /**
     * Build the connected-accounts markup.
     *
     * @return  string
     */
    protected function getInput(): string
    {
        $app  = Factory::getApplication();
        $user = $app->getIdentity();

        if (!$user || $user->guest || (int) $user->id <= 0) {
            return '';
        }

        // The link/unlink endpoints live in the system plugin; read its config.
        $sysPlugin = PluginHelper::getPlugin('system', 'vpsociallogin');

        if (!$sysPlugin) {
            return '';
        }

        $params   = new Registry($sysPlugin->params ?? '{}');
        $registry = new ProviderRegistry($params, $app);
        $enabled  = $registry->getEnabledProviders();

        if (empty($enabled)) {
            return '';
        }

        $linked = (new UserHelper($app, $params))->getLinkedProviders((int) $user->id);
        $token  = Session::getFormToken();
        $base   = Uri::root() . 'index.php?option=com_ajax&group=system&plugin=vpsociallogin&format=raw';

        // Return here after a connect/disconnect.
        $app->getSession()->set('vpsociallogin.return_url', Uri::current());
        $this->loadAssets($app);

        $rows = '';

        foreach ($enabled as $provider) {
            $key        = $provider->getKey();
            $title      = htmlspecialchars($provider->getTitle(), ENT_QUOTES, 'UTF-8');
            $icon       = $provider->getIcon();
            $isLinked   = \in_array($key, $linked, true);
            $rowClass   = 'vp-connected-item vpsl-' . htmlspecialchars($key, ENT_QUOTES, 'UTF-8');

            if ($isLinked) {
                $unlinkUrl = htmlspecialchars($base . '&vpsl=unlink&provider=' . urlencode($key) . '&' . $token . '=1', ENT_QUOTES, 'UTF-8');
                $action = '<span class="vp-connected-badge">' . Text::_('PLG_USER_VPSOCIALLOGIN_CONNECTED') . '</span>'
                    . '<a class="btn btn-sm btn-outline-danger" href="' . $unlinkUrl . '">'
                    . Text::_('PLG_USER_VPSOCIALLOGIN_DISCONNECT') . '</a>';
            } else {
                if (!$provider->isRedirectFlow() && $provider instanceof TelegramProvider) {
                    // Telegram: go straight to its OAuth. The callback URL carries a
                    // signed link token so the return (forwarded by buttons.js after
                    // the #tgAuthResult fragment) links Telegram to THIS user — no
                    // session needed (it would not survive the cross-site return).
                    $linkToken   = LinkToken::sign((int) $user->id);
                    $authUrl     = htmlspecialchars($provider->buildAuthUrl(Uri::current()), ENT_QUOTES, 'UTF-8');
                    $callbackUrl = htmlspecialchars(
                        $base . '&vpsl=callback&provider=' . urlencode($key) . '&vpsl_link=' . $linkToken,
                        ENT_QUOTES,
                        'UTF-8'
                    );

                    $action = '<a class="btn btn-sm btn-primary" href="' . $authUrl . '" data-vpsl-callback="' . $callbackUrl . '">'
                        . Text::_('PLG_USER_VPSOCIALLOGIN_CONNECT') . '</a>';
                } else {
                    // OAuth providers go through vsl=link (signed state carries the intent).
                    $linkUrl = htmlspecialchars(
                        $base . '&vpsl=link&provider=' . urlencode($key) . '&' . $token . '=1',
                        ENT_QUOTES,
                        'UTF-8'
                    );

                    $action = '<a class="btn btn-sm btn-primary" href="' . $linkUrl . '">'
                        . Text::_('PLG_USER_VPSOCIALLOGIN_CONNECT') . '</a>';
                }
            }

            $rows .= '<li class="' . $rowClass . '">'
                . '<span class="vp-connected-name">' . $icon . '<span>' . $title . '</span></span>'
                . '<span class="vp-connected-action">' . $action . '</span>'
                . '</li>';
        }

        return '<div class="vp-connected-accounts">'
            . '<p class="vp-connected-intro">' . Text::_('PLG_USER_VPSOCIALLOGIN_INTRO') . '</p>'
            . '<ul class="vp-connected-list">' . $rows . '</ul>'
            . '</div>';
    }

    /**
     * Register the shared script/style from the system plugin's media folder.
     *
     * @param   object  $app
     *
     * @return  void
     */
    private function loadAssets($app): void
    {
        $doc = $app->getDocument();

        if (!method_exists($doc, 'getWebAssetManager')) {
            return;
        }

        $wa = $doc->getWebAssetManager();

        $wa->registerAndUseStyle('vpsl.connected', 'plg_system_vpsociallogin/vpsociallogin.css');
        $wa->registerAndUseScript('vpsl.buttons', 'plg_system_vpsociallogin/buttons.js', [], ['defer' => true]);

        $doc->addStyleDeclaration(
            '.vp-connected-accounts .vp-connected-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:.5rem}'
            . '.vp-connected-accounts .vp-connected-item{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.6rem .85rem;border:1px solid #e2e8f0;border-radius:.5rem}'
            . '.vp-connected-accounts .vp-connected-name{display:inline-flex;align-items:center;gap:.5rem;font-weight:600}'
            . '.vp-connected-accounts .vp-connected-name svg{width:1.25rem;height:1.25rem}'
            . '.vp-connected-accounts .vp-connected-action{display:inline-flex;align-items:center;gap:.5rem}'
            . '.vp-connected-accounts .vp-connected-badge{font-size:.8rem;color:#16a34a;font-weight:600}'
            . '.vp-connected-accounts .vp-connected-intro{margin-bottom:.75rem;color:#64748b}'
        );
    }
}
